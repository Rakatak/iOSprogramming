//
//  Waypoint.swift
//  Aufgabe6
//
//  Created by master on 05.12.14.
//  Copyright (c) 2014 797459. All rights reserved.
//

import Foundation
import MapKit

class Waypoint: MKPointAnnotation{
    
    let name = "waypoint"
}


